import { ref } from 'vue'
import { invoke } from '@tauri-apps/api/core'

const teams = ref([
    { id: 1, name: '123', description: '123' },
    { id: 2, name: '123', description: '123' },
    { id: 3, name: '123', description: '123' },
    { id: 4, name: '123', description: '123' },
    { id: 5, name: '123', description: '123' },
    { id: 6, name: '123', description: '123' },
    { id: 7, name: '123', description: '123' },
    { id: 8, name: '123', description: '123' },
]);


export const team_create = async (name: string, description: string): Promise<any> => {
    let last_team = teams.value[teams.value.length - 1];
    teams.value.push({ id: last_team.id, name, description })
};

export const team_query_id = async (id: number): Promise<any> => {
    return teams.value.find(item => item.id = id)
};

export const team_query = async (pageNum: number, pageSize: number): Promise<any> => {
    return teams.value.splice(0, 5)
};

export const team_update = async (id: number, name: string, description: string): Promise<any> => {
    teams.value[id] = { id, name, description }
};

export const team_delete = async (id: number): Promise<any> => {
    teams.value = teams.value.filter(item => item.id != id)
    // return await invoke('environment_delete', { id })
};

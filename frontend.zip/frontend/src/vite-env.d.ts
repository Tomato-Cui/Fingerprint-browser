/// <reference types="vite/client" />
/// <reference types="vite-svg-loader" />

export { default as IconLogo } from "./logo.svg";
export { default as IconAddCircle } from "./Add Circle.svg";
export { default as IconGlobal } from "./Global.svg";
export { default as IconCardShopping } from "./Card Shopping Card.svg";
export { default as IconButtonLight } from "./Button-light.svg";
export { default as IconPlate } from "./Essentional UI/Plate.svg";
export { default as IconTrashBin } from "./Essentional UI/Trash Bin Trash.svg";
export { default as IconAvatarOnline } from "./Avatar/online.svg";
export { default as IconImport } from "./Arrows Action/Import.svg";
export { default as IconRestart } from "./Arrows/Restart.svg";
export { default as IconHeadphonesRound } from "./Electronic  Devices/Headphones Round.svg";
export { default as IconMailbox } from "./Messages Conversation/Mailbox.svg";
export { default as IconVector } from "./Vector.svg";
export { default as IconGroup1 } from "./Group 1.svg";
export { default as IconSettings } from "./Settings.svg";

export { default as IconHomeSmile } from './HomeSmile.vue'
export { default as IconExtensions } from "./extensions.vue";
export { default as IconUsersGroupRounded } from "./Users/UsersGroupRounded.vue";
export { default as Circle } from "./circle.svg";

export { default as Filter } from "./filter.svg";

export { default as File } from "./file.svg";
export { default as BrowsersChromeIcon } from "./Browsers.svg"
export { default as BrowsersFoxIcon } from "./Browsers (1).vue"
export { default as CheckBeadIcon } from "./Check Read.svg"
export { default as ContentUploadIcon } from "./Content upload 1.vue"
export { default as EditIcon } from "./edit.svg"
export { default as EmptyInboxIcon } from "./Empty Inbox 1.vue"
export { default as LoginIcon } from "./Login 5.svg"
export { default as PaintRollerIcon } from "./Paint Roller.svg"
export { default as QRCodeIcon } from "./QR Code.svg"
export { default as RefreshIcon } from "./Refresh.svg"
export { default as WidgetIcon } from "./Widget 18.svg"
export { default as WrapperIcon } from "./Icon-Wrapper.svg"
export { default as LogoutBlackIcon } from "./logout-black.svg"
export { default as KeyIcon } from './Key.svg'
export { default as ContentUnavailableIcon } from './Content unavailable 1.vue'
export { default as InfoCircleIcon } from './info-circle.svg'
export { default as CopyIcon } from './copy.svg'
export { default as ClearIcon } from './Clear.svg'
export { default as RecomIcon } from './recom.svg'
export { default as GroupIcon } from './Group 10.svg'
export { default as SocialMediaFlyBookIcon } from './Social Media fly book.svg'
export { default as SocialMediaWeChatIcon} from './Social Media WeChat.svg'
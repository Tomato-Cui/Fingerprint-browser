<script></script>

<template>
    <svg viewBox="0 0 168 148" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#clip0_848_78001)">
            <path
                d="M9.61764 98.1282C25.7125 69.2952 15.5769 68.2592 7.60028 59.1998C-0.0393074 50.5234 -1.27512 37.2857 1.06462 26.009C3.39948 14.7275 12.1381 4.39017 23.5633 2.2888C40.8792 -0.892304 56.8376 14.4854 74.4368 13.8657C83.3952 13.5461 91.5968 9.11097 100.125 6.37047C120.318 -0.117605 145.054 4.27395 158.067 20.9009C169.482 35.4797 169.829 55.9899 165.252 73.8804C160.582 92.1292 150.964 109.594 135.905 121.064C120.846 132.534 99.9492 137.197 82.2036 130.491C69.5424 125.703 56.808 115.409 44.1128 120.106C39.9513 121.645 21.0526 130.322 12.568 120.522C8.91912 116.305 6.384 103.929 9.61764 98.1334V98.1282Z"
                fill="url(#paint0_linear_848_78001)" />
            <g filter="url(#filter0_dd_848_78001)">
                <path
                    d="M19.9117 23.3533C14.6147 25.6197 12.3973 31.8958 15.1362 36.9434C18.8753 43.8501 23.001 51.2826 26.656 59.5956C31.9244 71.5864 35.2124 83.0316 38.7882 92.9131C38.8466 93.079 39.2402 93.9062 40.2204 94.2999C40.8444 94.5431 41.5564 94.551 42.2196 94.2717C52.2936 89.9626 67.9784 83.2594 82.5252 77.0303C87.1408 75.0547 89.4756 69.9259 87.92 65.1907C85.3404 57.3372 82.5824 48.5163 78.3284 39.3571C74.4444 30.9895 70.3064 23.6161 66.29 17.2215L47.9804 11.3105C47.9804 11.3105 31.142 18.5586 19.9266 23.3563L19.9117 23.3533Z"
                    fill="url(#paint1_linear_848_78001)" />
                <path
                    d="M55.5437 22.9852L66.2881 17.2872L47.9805 11.3105L53.2473 22.2291C53.6653 23.0613 54.6957 23.4065 55.5349 22.9915L55.5437 22.9852Z"
                    fill="#9C9CF0" />
            </g>
            <g filter="url(#filter1_dd_848_78001)">
                <path
                    d="M97.231 10.3448C95.4966 9.45891 93.3722 10.124 92.4638 11.8352C87.7314 24.4744 81.7454 38.4314 74.0754 53.175C65.905 68.89 57.3638 82.5861 49.2346 94.2654C49.125 94.4749 48.5638 95.5792 49.0042 96.9373C49.2734 97.7956 49.8762 98.5499 50.737 98.9947L111.252 130.218C112.986 131.104 115.111 130.439 116.019 128.728C123.771 118.031 132.02 105.008 139.625 89.5957C144.817 79.073 148.897 69.059 152.125 59.8747C149.225 51.3129 146.327 42.7511 143.427 34.1893L97.2342 10.3573L97.231 10.3448Z"
                    fill="url(#paint2_linear_848_78001)" />
                <path
                    d="M141.51 58.3492L90.7361 32.6825C89.4653 32.0401 88.0561 32.2567 87.5889 33.1664C87.1213 34.0761 87.7729 35.3344 89.0437 35.9768L139.817 61.6433C141.088 62.2857 142.497 62.0691 142.965 61.1596C143.432 60.2498 142.781 58.9916 141.51 58.3492Z"
                    fill="#D7D7FF" />
                <path
                    d="M137.995 66.188L87.2215 40.5213C85.9507 39.879 84.5415 40.0956 84.0743 41.005C83.6067 41.9148 84.2583 43.173 85.5291 43.8154L136.303 69.4821C137.573 70.1245 138.983 69.9079 139.45 68.9984C139.917 68.0886 139.266 66.8304 137.995 66.188Z"
                    fill="#D7D7FF" />
                <path
                    d="M126.907 70.163L83.683 48.3126C82.601 47.7658 81.345 48.0598 80.8778 48.9696C80.4102 49.8791 80.9086 51.0599 81.9902 51.607L125.214 73.4571C126.296 74.0043 127.552 73.7098 128.019 72.8004C128.487 71.8906 127.989 70.7098 126.907 70.163Z"
                    fill="#D7D7FF" />
                <path
                    d="M132.694 81.7779L80.7995 55.5446C79.5007 54.8879 78.0687 55.0931 77.6015 56.0029C77.1339 56.9123 77.8083 58.1824 79.1071 58.8387L131.002 85.072C132.3 85.7287 133.732 85.5235 134.2 84.6137C134.667 83.7043 133.993 82.4346 132.694 81.7779Z"
                    fill="#D7D7FF" />
                <path
                    d="M128.519 89.356L76.6247 63.1227C75.3259 62.4661 73.8939 62.6712 73.4267 63.581C72.9591 64.4904 73.6335 65.7601 74.9323 66.4168L126.827 92.6501C128.125 93.3068 129.558 93.1017 130.025 92.1918C130.492 91.2824 129.818 90.0127 128.519 89.356Z"
                    fill="#D7D7FF" />
                <path
                    d="M124.931 97.1657L73.0371 70.9328C71.7383 70.2761 70.3063 70.4813 69.8387 71.3907C69.3715 72.3005 70.0454 73.5702 71.3442 74.2269L123.239 100.46C124.538 101.117 125.969 100.912 126.437 100.002C126.904 99.0921 126.23 97.8224 124.931 97.1657Z"
                    fill="#D7D7FF" />
                <path
                    d="M136.728 51.9178L152.135 59.8598L143.438 34.1743L135.759 48.8277C135.176 49.9502 135.609 51.3361 136.741 51.9146L136.728 51.9178Z"
                    fill="#9C9CF0" />
            </g>
            <g filter="url(#filter2_dd_848_78001)">
                <g filter="url(#filter3_dddd_848_78001)">
                    <path
                        d="M46.3203 112.042C58.0727 111.976 67.5459 102.472 67.4795 90.8139C67.4131 79.1556 57.8319 69.7582 46.0795 69.8241C34.3271 69.8903 24.8538 79.3945 24.9203 91.0527C24.9867 102.711 34.5679 112.108 46.3203 112.042Z"
                        fill="#9C9CF0" />
                </g>
            </g>
            <path
                d="M53.9473 87.3955C53.3733 86.8273 52.7337 86.3245 52.0429 85.8928V80.8898C52.0429 80.8148 52.0393 80.7418 52.0377 80.6668C52.0409 80.6295 52.0429 80.5918 52.0429 80.5545C52.0445 77.3815 49.4357 74.8008 46.2297 74.8008C43.0241 74.8008 40.4169 77.3815 40.4169 80.5545V85.8928C39.7262 86.3245 39.0864 86.8273 38.5123 87.3955C36.5385 89.3492 35.3164 92.0501 35.3164 95.0347C35.3164 101.002 40.2033 105.837 46.2297 105.837C49.2433 105.837 51.9721 104.627 53.9473 102.672C55.9229 100.717 57.1449 98.0154 57.1449 95.0327C57.1449 92.0501 55.9229 89.3492 53.9473 87.3939V87.3955ZM42.7133 80.8898C42.7133 78.9702 44.2905 77.4088 46.2297 77.4088C48.1693 77.4088 49.7465 78.9702 49.7465 80.8898V84.8084C48.6429 84.4374 47.4601 84.2323 46.2297 84.2323C44.9997 84.2323 43.8169 84.4374 42.7133 84.8084V80.8898ZM47.5869 96.0604L47.9585 98.3233C48.0161 98.678 47.7397 98.999 47.3781 98.999H45.0869C44.7217 98.999 44.4453 98.6732 44.5061 98.3185L44.8925 96.0683C44.0769 95.6077 43.5273 94.7383 43.5273 93.7436C43.5273 92.2652 44.7381 91.0669 46.2317 91.0669C47.7249 91.0669 48.9357 92.2652 48.9357 93.7436C48.9357 94.7316 48.3945 95.5962 47.5885 96.0584L47.5869 96.0604Z"
                fill="url(#paint3_linear_848_78001)" />
        </g>
        <defs>
            <filter id="filter0_dd_848_78001" x="-0.641993" y="11.3105" width="103.642" height="119.31"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="8.61538" />
                <feGaussianBlur stdDeviation="4.30769" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_848_78001" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="21.5385" />
                <feGaussianBlur stdDeviation="7.3" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_848_78001" result="effect2_dropShadow_848_78001" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_848_78001" result="shape" />
            </filter>
            <filter id="filter1_dd_848_78001" x="22.9917" y="5.64494" width="154.989" height="172.35"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="8.61538" />
                <feGaussianBlur stdDeviation="4.30769" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_848_78001" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="21.5385" />
                <feGaussianBlur stdDeviation="12.9231" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_848_78001" result="effect2_dropShadow_848_78001" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_848_78001" result="shape" />
            </filter>
            <filter id="filter2_dd_848_78001" x="-0.926279" y="65.516" width="94.252" height="93.9112"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="8.61538" />
                <feGaussianBlur stdDeviation="4.30769" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_848_78001" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="21.5385" />
                <feGaussianBlur stdDeviation="12.9231" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_848_78001" result="effect2_dropShadow_848_78001" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_848_78001" result="shape" />
            </filter>
            <filter id="filter3_dddd_848_78001" x="-0.926279" y="65.516" width="94.252" height="93.9112"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="8.61538" />
                <feGaussianBlur stdDeviation="4.30769" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_848_78001" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="21.5385" />
                <feGaussianBlur stdDeviation="12.9231" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_848_78001" result="effect2_dropShadow_848_78001" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="8.61538" />
                <feGaussianBlur stdDeviation="4.30769" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="effect2_dropShadow_848_78001" result="effect3_dropShadow_848_78001" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="21.5385" />
                <feGaussianBlur stdDeviation="12.9231" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect3_dropShadow_848_78001" result="effect4_dropShadow_848_78001" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect4_dropShadow_848_78001" result="shape" />
            </filter>
            <linearGradient id="paint0_linear_848_78001" x1="102.211" y1="157.649" x2="66.0619" y2="-50.8663"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.05" stop-color="#F6F8FF" />
                <stop offset="0.13" stop-color="#DFE5FF" />
                <stop offset="0.47" stop-color="#E9EDFF" />
                <stop offset="0.84" stop-color="#EFF2FF" />
                <stop offset="1" stop-color="white" />
            </linearGradient>
            <linearGradient id="paint1_linear_848_78001" x1="42.9996" y1="22.0908" x2="79.8761" y2="83.1173"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.8" stop-color="#ECEEFF" />
            </linearGradient>
            <linearGradient id="paint2_linear_848_78001" x1="107.08" y1="61.6685" x2="71.6225" y2="141.811"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.78" stop-color="#ECEEFF" />
            </linearGradient>
            <linearGradient id="paint3_linear_848_78001" x1="35.3164" y1="90.3198" x2="57.1449" y2="90.3198"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.78" stop-color="#ECEEFF" />
            </linearGradient>
            <clipPath id="clip0_848_78001">
                <rect width="168" height="148" fill="white" />
            </clipPath>
        </defs>
    </svg>

</template>

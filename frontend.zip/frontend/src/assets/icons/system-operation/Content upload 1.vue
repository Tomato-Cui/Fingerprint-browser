<script setup></script>

<template>
    <svg viewBox="0 0 116 105" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#clip0_330_51801)">
            <path
                d="M6.64075 69.623C17.7539 49.3617 10.7555 48.6337 5.24781 42.2677C-0.0271408 36.1707 -0.880442 26.8686 0.735095 18.9444C2.34726 11.0169 8.38108 3.75281 16.2699 2.27617C28.2261 0.0408065 39.245 10.8468 51.3968 10.4113C57.5824 10.1867 63.2454 7.07013 69.1341 5.14437C83.077 0.585187 100.156 3.67114 109.141 15.3549C117.024 25.5995 117.263 40.012 114.103 52.5838C110.878 65.4073 104.237 77.6798 93.8393 85.74C83.4413 93.8004 69.0125 97.0768 56.7596 92.3645C48.0174 88.9994 39.2246 81.7659 30.4588 85.0663C27.5854 86.1484 14.5363 92.2454 8.67788 85.3588C6.15844 82.3955 4.408 73.6991 6.64075 69.6264V69.623Z"
                fill="url(#paint0_linear_330_51801)" />
            <g filter="url(#filter0_dd_330_51801)">
                <path
                    d="M13.7488 17.0786C10.0914 18.6712 8.56032 23.0814 10.4515 26.6283C13.0332 31.4817 15.8819 36.7046 18.4056 42.5462C22.0433 50.9721 24.3136 59.0147 26.7826 65.9584C26.823 66.075 27.0947 66.6563 27.7715 66.9329C28.2024 67.1038 28.694 67.1094 29.1519 66.9131C36.1078 63.8851 46.9378 59.1747 56.982 54.7975C60.1689 53.4093 61.7811 49.8053 60.707 46.4778C58.9258 40.9591 57.0215 34.7607 54.0842 28.3245C51.4024 22.4446 48.5452 17.2632 45.772 12.7697L33.1296 8.6161C33.1296 8.6161 21.5031 13.7093 13.7591 17.0807L13.7488 17.0786Z"
                    fill="url(#paint1_linear_330_51801)" />
                <path
                    d="M38.3518 16.8196L45.7706 12.8156L33.1296 8.6158L36.7662 16.2882C37.0549 16.8731 37.7663 17.1157 38.3458 16.824L38.3518 16.8196Z"
                    fill="#9C9CF0" />
            </g>
            <g filter="url(#filter1_dd_330_51801)">
                <path
                    d="M67.1358 7.93726C65.9383 7.31477 64.4714 7.78212 63.8442 8.98459C60.5766 17.8662 56.4434 27.6738 51.1475 38.0341C45.506 49.077 39.6085 58.7014 33.9955 66.9084C33.9198 67.0559 33.5323 67.8316 33.8364 68.786C34.0223 69.3891 34.4385 69.9194 35.0329 70.2317L76.8169 92.1726C78.0144 92.7952 79.4813 92.3279 80.1088 91.1254C85.4608 83.6087 91.1567 74.4575 96.4076 63.627C99.9931 56.2327 102.81 49.1958 105.039 42.742C103.037 36.7256 101.035 30.7092 99.0334 24.6929L67.1381 7.94604L67.1358 7.93726Z"
                    fill="url(#paint2_linear_330_51801)" />
                <path
                    d="M97.7094 41.6699L62.6514 23.6339C61.7739 23.1825 60.8009 23.3347 60.4783 23.9739C60.1555 24.6132 60.6054 25.4973 61.4828 25.9488L96.5408 43.9847C97.4183 44.4364 98.3913 44.2841 98.7139 43.6448C99.0367 43.0055 98.5868 42.1213 97.7094 41.6699Z"
                    fill="#9C9CF0" />
                <path
                    d="M95.2822 47.1783L60.2243 29.1422C59.3468 28.6908 58.3738 28.843 58.0512 29.4821C57.7283 30.1214 58.1783 31.0056 59.0557 31.457L94.1137 49.493C94.9911 49.9445 95.9642 49.7922 96.2867 49.1532C96.6093 48.5138 96.1597 47.6297 95.2822 47.1783Z"
                    fill="#9C9CF0" />
                <path
                    d="M87.6265 49.9718L57.7813 34.6174C57.0342 34.2332 56.167 34.4398 55.8444 35.0792C55.5215 35.7182 55.8657 36.548 56.6125 36.9325L86.4576 52.2866C87.2047 52.671 88.072 52.4644 88.3946 51.8251C88.7174 51.1858 88.3733 50.356 87.6265 49.9718Z"
                    fill="#9C9CF0" />
                <path
                    d="M91.6224 58.1334L55.7906 39.6992C54.8938 39.2377 53.905 39.3819 53.5824 40.0212C53.2596 40.6606 53.7252 41.5528 54.622 42.0142L90.4539 60.4482C91.3507 60.9096 92.3394 60.7655 92.662 60.1264C92.9849 59.4871 92.5192 58.5948 91.6224 58.1334Z"
                    fill="#9C9CF0" />
                <path
                    d="M88.7395 63.4586L52.9076 45.0244C52.0108 44.5629 51.0221 44.7071 50.6995 45.3464C50.3766 45.9855 50.8423 46.878 51.7391 47.3391L87.5709 65.7734C88.4677 66.2348 89.4565 66.0907 89.7791 65.4513C90.1019 64.8123 89.6363 63.92 88.7395 63.4586Z"
                    fill="#9C9CF0" />
                <path
                    d="M86.2624 68.9466L50.4305 50.5127C49.5334 50.0512 48.545 50.1954 48.2221 50.8345C47.8995 51.4738 48.3649 52.366 49.2617 52.8275L85.0935 71.2617C85.9906 71.7231 86.9791 71.579 87.3019 70.9396C87.6245 70.3003 87.1592 69.4081 86.2624 68.9466Z"
                    fill="#9C9CF0" />
                <path
                    d="M94.4078 37.1505L105.045 42.7314L99.0403 24.6821L93.7386 34.979C93.3356 35.7678 93.635 36.7417 94.4163 37.1485L94.4078 37.1505Z"
                    fill="#9C9CF0" />
            </g>
            <g filter="url(#filter2_dd_330_51801)">
                <g filter="url(#filter3_dddd_330_51801)">
                    <path
                        d="M36.5303 79.7713C44.4136 79.7264 50.7679 73.2352 50.7235 65.2726C50.679 57.3103 44.2523 50.8922 36.369 50.9373C28.486 50.9822 22.1314 57.4734 22.176 65.436C22.2206 73.3983 28.6473 79.8164 36.5303 79.7713Z"
                        fill="#9C9CF0" />
                </g>
            </g>
            <path
                d="M37.5363 56.1976C37.2424 55.9003 36.8441 55.7336 36.4287 55.7336C36.0136 55.7336 35.6153 55.9003 35.3215 56.1976L29.4093 62.178C29.1155 62.4758 28.9503 62.8792 28.9503 63.3C28.9503 63.7207 29.1155 64.1244 29.4093 64.4219C29.7032 64.7194 30.102 64.8865 30.5177 64.8865C30.9336 64.8865 31.3322 64.7194 31.6263 64.4219L34.8616 61.1483V73.3453C34.8616 73.7658 35.0268 74.1692 35.3207 74.4667C35.6145 74.7642 36.0131 74.9312 36.4287 74.9312C36.8444 74.9312 37.2429 74.7642 37.5368 74.4667C37.8307 74.1692 37.9958 73.7658 37.9958 73.3453V61.1483L41.2303 64.4219C41.3758 64.5692 41.5487 64.686 41.7388 64.7657C41.9291 64.8455 42.1329 64.8865 42.3386 64.8865C42.5447 64.8865 42.7485 64.8455 42.9385 64.7657C43.1288 64.686 43.3017 64.5692 43.4473 64.4219C43.5928 64.2744 43.7083 64.0996 43.787 63.9072C43.8657 63.7146 43.9063 63.5082 43.9063 63.3C43.9063 63.0917 43.8657 62.8854 43.787 62.6927C43.7083 62.5003 43.5928 62.3255 43.4473 62.178L37.5363 56.1976Z"
                fill="url(#paint3_linear_330_51801)" />
        </g>
        <defs>
            <filter id="filter0_dd_330_51801" x="3.4577" y="8.6158" width="63.7611" height="73.7425"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="3.64692" />
                <feGaussianBlur stdDeviation="1.82346" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_330_51801" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="9.11733" />
                <feGaussianBlur stdDeviation="3.09012" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_330_51801" result="effect2_dropShadow_330_51801" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_330_51801" result="shape" />
            </filter>
            <filter id="filter1_dd_330_51801" x="22.7808" y="5.83823" width="93.2053" height="106.668"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="3.64692" />
                <feGaussianBlur stdDeviation="1.82346" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_330_51801" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="9.11733" />
                <feGaussianBlur stdDeviation="5.4704" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_330_51801" result="effect2_dropShadow_330_51801" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_330_51801" result="shape" />
            </filter>
            <filter id="filter2_dd_330_51801" x="11.235" y="49.1136" width="50.4296" height="50.716"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="3.64692" />
                <feGaussianBlur stdDeviation="1.82346" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_330_51801" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="9.11733" />
                <feGaussianBlur stdDeviation="5.4704" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_330_51801" result="effect2_dropShadow_330_51801" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_330_51801" result="shape" />
            </filter>
            <filter id="filter3_dddd_330_51801" x="11.235" y="49.1136" width="50.4296" height="50.716"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="3.64692" />
                <feGaussianBlur stdDeviation="1.82346" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_330_51801" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="9.11733" />
                <feGaussianBlur stdDeviation="5.4704" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect1_dropShadow_330_51801" result="effect2_dropShadow_330_51801" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="3.64692" />
                <feGaussianBlur stdDeviation="1.82346" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix"
                    values="0 0 0 0 0.0901961 0 0 0 0 0.219608 0 0 0 0 0.482353 0 0 0 0.03 0" />
                <feBlend mode="normal" in2="effect2_dropShadow_330_51801" result="effect3_dropShadow_330_51801" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha" />
                <feOffset dy="9.11733" />
                <feGaussianBlur stdDeviation="5.4704" />
                <feComposite in2="hardAlpha" operator="out" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.0902477 0 0 0 0 0.2203 0 0 0 0 0.480404 0 0 0 0.08 0" />
                <feBlend mode="normal" in2="effect3_dropShadow_330_51801" result="effect4_dropShadow_330_51801" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect4_dropShadow_330_51801" result="shape" />
            </filter>
            <linearGradient id="paint0_linear_330_51801" x1="70.5741" y1="111.448" x2="44.7493" y2="-34.9235"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.05" stop-color="#F6F8FF" />
                <stop offset="0.13" stop-color="#DFE5FF" />
                <stop offset="0.47" stop-color="#E9EDFF" />
                <stop offset="0.84" stop-color="#EFF2FF" />
                <stop offset="1" stop-color="white" />
            </linearGradient>
            <linearGradient id="paint1_linear_330_51801" x1="29.6905" y1="16.1914" x2="55.8129" y2="58.669"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.8" stop-color="#ECEEFF" />
            </linearGradient>
            <linearGradient id="paint2_linear_330_51801" x1="73.9362" y1="44.0025" x2="48.7265" y2="99.9917"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.78" stop-color="#ECEEFF" />
            </linearGradient>
            <linearGradient id="paint3_linear_330_51801" x1="28.9511" y1="65.3248" x2="43.9243" y2="65.3248"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="white" />
                <stop offset="0.78" stop-color="#ECEEFF" />
            </linearGradient>
            <clipPath id="clip0_330_51801">
                <rect width="116" height="104" fill="white" transform="translate(0 0.667969)" />
            </clipPath>
        </defs>
    </svg>
</template>
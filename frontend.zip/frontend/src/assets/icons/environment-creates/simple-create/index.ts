export { default as IconFrame1 } from './Frame-1.svg'
export { default as IconFrame2 } from './Frame-2.svg'
export { default as IconFrame3 } from './Frame-3.svg'
export { default as IconFrame4 } from './Frame-4.svg'
export { default as IconFrame } from './Frame.svg'
export { default as IconChrome } from './chrome.svg'
export { default as IconRulerCrossPen } from './Design Tools/Ruler Cross Pen.svg';
export { default as IconStarFallMinimalistic } from './Astronomy/Star Fall Minimalistic 2.svg';
export { default as IconLoginArrow } from './Arrows Action/Login 5.svg';
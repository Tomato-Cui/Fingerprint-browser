export { default as IconBookMark } from "./bookmark.svg";

export { default as IconApple } from "./add-card.svg";

export { default as NewBookmark } from "./new-bookmark.svg";

export { default as AddCircle } from "./add-circle.svg";

export { default as SearchIcon } from "./search.svg";

export { default as ChevronRightIcon } from "./right.svg";

export { default as ChevronLeftIcon } from "./left.svg";



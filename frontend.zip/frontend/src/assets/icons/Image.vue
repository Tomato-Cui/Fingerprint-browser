<template>
<svg viewBox="0 0 47 37" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.74069 5.97699L12.0075 5.09918V27.359L10.8294 27.607C7.54068 28.2994 4.32467 26.1557 3.69843 22.8537L1.83216 13.0134C1.20495 9.70627 3.42045 6.53036 6.74069 5.97699Z" stroke="#5050FA" stroke-width="2"/>
<path d="M40.6656 5.97699L35.3987 5.09918V27.359L36.5768 27.607C39.8656 28.2994 43.0816 26.1557 43.7078 22.8537L45.5741 13.0134C46.2013 9.70627 43.9858 6.53036 40.6656 5.97699Z" stroke="#5050FA" stroke-width="2"/>
<g filter="url(#filter0_dd_851_38601)">
<rect x="12.2529" y="1.57178" width="22.9008" height="27.4282" rx="5" stroke="#5050FA" stroke-width="2" shape-rendering="crispEdges"/>
</g>
<path d="M30.1537 29H17.2529C14.4915 29 12.2529 26.7614 12.2529 24L12.2529 23.9149L20.0582 15.6435L25.8034 22.2549C26.6041 23.1763 28.0363 23.1717 28.8311 22.2452L31.7657 18.8243L35.1537 22.47V24C35.1537 26.7614 32.9152 29 30.1537 29Z" fill="#EFF6FF" stroke="#5050FA" stroke-width="2"/>
<circle cx="26.7212" cy="10.004" r="2.39556" fill="#EFF6FF" stroke="#5050FA" stroke-width="2"/>
<defs>
<filter id="filter0_dd_851_38601" x="8.25293" y="0.571777" width="30.9009" height="36.4282" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="2"/>
<feGaussianBlur stdDeviation="1"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_851_38601"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="4"/>
<feGaussianBlur stdDeviation="1.5"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.07 0"/>
<feBlend mode="normal" in2="effect1_dropShadow_851_38601" result="effect2_dropShadow_851_38601"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_851_38601" result="shape"/>
</filter>
</defs>
</svg>
</template>
<script setup lang="ts">
</script>
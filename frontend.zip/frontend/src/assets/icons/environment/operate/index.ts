export { default as InfoCircleIcon } from './info-circle.svg'
export { default as ShoppingCartIcon } from './ShoppingCart.svg'
export { default as QuestionCircleIcon } from './Question Circle.svg'
export { default as FormatIcon } from './文件格式icon.svg'
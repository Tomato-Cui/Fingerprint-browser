import Model from './model.vue'
import { DialogClose as ModelClose } from '@/components/ui/dialog'

export { Model, ModelClose }
<script setup>
import { LoaderCircle } from 'lucide-vue-next'
</script>

<template>
    <LoaderCircle class="animate-spin transition ease-in-out delay-150 text-blue-500" />
</template>

<style scoped></style>